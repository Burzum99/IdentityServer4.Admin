$templateNuspecPath = "template-publish/Skoruba.IdentityServer4.Admin.Templates.nuspec"

nuget pack $templateNuspecPath