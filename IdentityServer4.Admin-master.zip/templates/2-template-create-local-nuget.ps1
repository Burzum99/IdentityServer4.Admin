$templateNuspecPath = "template-build/Skoruba.IdentityServer4.Admin.Templates.nuspec"

nuget pack $templateNuspecPath