﻿namespace SkorubaIdentityServer4Admin.Admin.Api.Dtos.ApiResources
{
    public class ApiResourcePropertyApiDto
    {
        public int Id { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}