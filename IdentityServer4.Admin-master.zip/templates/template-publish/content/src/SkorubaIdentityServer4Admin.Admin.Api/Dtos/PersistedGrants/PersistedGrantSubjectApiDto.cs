﻿namespace SkorubaIdentityServer4Admin.Admin.Api.Dtos.PersistedGrants
{
    public class PersistedGrantSubjectApiDto
    {
        public string SubjectId { get; set; }
        public string SubjectName { get; set; }
    }
}