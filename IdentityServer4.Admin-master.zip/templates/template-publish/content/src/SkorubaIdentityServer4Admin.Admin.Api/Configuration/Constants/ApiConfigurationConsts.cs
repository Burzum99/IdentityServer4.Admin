﻿namespace SkorubaIdentityServer4Admin.Admin.Api.Configuration.Constants
{
    public class ApiConfigurationConsts
    {
        public const string ApiName = "Skoruba IdentityServer4 Admin Api";

        public const string ApiVersionV1 = "v1";
    }
}
