﻿using Microsoft.Extensions.Localization;

namespace SkorubaIdentityServer4Admin.Admin.Api.Helpers.Localization
{
    public interface IGenericControllerLocalizer<T> : IStringLocalizer<T>
    {

    }
}