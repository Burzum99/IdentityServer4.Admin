$templateLocalName = "Skoruba.IdentityServer4.Admin.Templates.1.0.0-beta7.nupkg"

dotnet.exe new -i $templateLocalName