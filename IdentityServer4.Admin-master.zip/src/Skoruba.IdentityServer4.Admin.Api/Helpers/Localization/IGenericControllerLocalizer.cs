﻿using Microsoft.Extensions.Localization;

namespace Skoruba.IdentityServer4.Admin.Api.Helpers.Localization
{
    public interface IGenericControllerLocalizer<T> : IStringLocalizer<T>
    {

    }
}