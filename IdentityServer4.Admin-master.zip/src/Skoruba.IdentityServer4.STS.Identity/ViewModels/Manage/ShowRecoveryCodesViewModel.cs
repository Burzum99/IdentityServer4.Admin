﻿namespace Skoruba.IdentityServer4.STS.Identity.ViewModels.Manage
{
    public class ShowRecoveryCodesViewModel
    {
        public string[] RecoveryCodes { get; set; }
    }
}
