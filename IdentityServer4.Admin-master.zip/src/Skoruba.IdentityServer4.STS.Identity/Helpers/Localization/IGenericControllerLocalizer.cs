﻿using Microsoft.Extensions.Localization;

namespace Skoruba.IdentityServer4.STS.Identity.Helpers.Localization
{
    public interface IGenericControllerLocalizer<T> : IStringLocalizer<T>
    {
        
    }
}