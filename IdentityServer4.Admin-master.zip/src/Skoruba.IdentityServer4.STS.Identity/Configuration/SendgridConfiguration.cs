﻿namespace Skoruba.IdentityServer4.STS.Identity.Configuration
{
    public class SendgridConfiguration
    {
        public string SourceEmail { get; set; }
        public string SourceName { get; set; }
        public string ApiKey { get; set; }
    }
}
