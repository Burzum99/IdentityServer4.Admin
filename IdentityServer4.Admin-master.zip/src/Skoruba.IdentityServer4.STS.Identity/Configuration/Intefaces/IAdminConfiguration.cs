﻿namespace Skoruba.IdentityServer4.STS.Identity.Configuration.Intefaces
{
    public interface IAdminConfiguration
    {
        string IdentityAdminBaseUrl { get; }
    }
}