﻿namespace Skoruba.IdentityServer4.STS.Identity.Configuration.Intefaces
{
    public interface IRegisterConfiguration
    {
        bool Enabled { get; }
    }
}