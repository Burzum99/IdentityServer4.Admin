﻿window.addEventListener("load", function () {
    window.cookieconsent.initialise({
        "content": {
            "message": "This website uses cookies to keep you logged in and ensure that you get the best experience on our website. Your personal data never leaves this website until you explicitly allow for it in consent screen.",
            "target": "_self"
        }
    });
});