﻿namespace Skoruba.IdentityServer4.Admin.BusinessLogic.Shared.ExceptionHandling
{
    public class ViewErrorMessage
    {
        public string ErrorKey { get; set; }

        public string ErrorMessage { get; set; }
    }
}
