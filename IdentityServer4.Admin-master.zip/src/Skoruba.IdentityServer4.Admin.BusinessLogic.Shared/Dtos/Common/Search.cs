﻿namespace Skoruba.IdentityServer4.Admin.BusinessLogic.Shared.Dtos.Common
{
    public class Search
    {
        public string Action { get; set; }

        public string Controller { get; set; }
    }
}