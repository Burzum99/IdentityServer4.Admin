﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Constants
{
    public static class TableConsts
    {
        public const string Logging = "Log";
    }
}
