﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Helpers
{
	public enum HashType
	{
		Sha256,
		Sha512
	}
}
