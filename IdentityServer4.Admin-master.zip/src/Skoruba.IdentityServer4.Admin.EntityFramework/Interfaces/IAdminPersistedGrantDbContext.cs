﻿using IdentityServer4.EntityFramework.Interfaces;

namespace Skoruba.IdentityServer4.Admin.EntityFramework.Interfaces
{
    public interface IAdminPersistedGrantDbContext : IPersistedGrantDbContext
    {

    }
}
