﻿$(function() {

    var adminDatePicker = {

        initDatePickers: function () {
            $('.datepicker').datepicker({
                autoclose: true,
                todayHighlight: true
            });
        }

    };


    adminDatePicker.initDatePickers();
})