﻿Holder.addTheme('thumb', {
	bg: '#55595c',
	fg: '#eceeef',
	text: 'Thumbnail'
});