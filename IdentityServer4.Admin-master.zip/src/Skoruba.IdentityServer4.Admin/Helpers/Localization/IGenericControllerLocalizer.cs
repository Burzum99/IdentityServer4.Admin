﻿using Microsoft.Extensions.Localization;

namespace Skoruba.IdentityServer4.Admin.Helpers.Localization
{
    public interface IGenericControllerLocalizer<T> : IStringLocalizer<T>
    {
        
    }
}