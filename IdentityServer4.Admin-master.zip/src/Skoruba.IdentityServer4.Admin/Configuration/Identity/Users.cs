﻿namespace Skoruba.IdentityServer4.Admin.Configuration.Identity
{
    public class Users
    {
        public const string AdminUserName = "admin";
        public const string AdminPassword = "Pa$$word123";
        public const string AdminEmail = "admin@example.com";
    }
}
